increment <-
function(counter) {
  counter = counter + 1
  return(counter)
}
